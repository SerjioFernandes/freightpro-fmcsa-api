import { Request, Response, NextFunction } from 'express';
export declare function validateAuthority(req: Request, res: Response, next: NextFunction): void;
export declare function validateEINRequired(req: Request, res: Response, next: NextFunction): void;
//# sourceMappingURL=validation.middleware.d.ts.map