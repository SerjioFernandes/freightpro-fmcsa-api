import { Response, NextFunction } from 'express';
import { AuthRequest } from '../types/index.js';
import { AccountType } from '../types/index.js';
/**
 * Middleware to require specific account types
 * Returns 403 Forbidden if user doesn't have one of the allowed account types
 */
export declare const requireAccountType: (allowedTypes: AccountType[]) => (req: AuthRequest, res: Response, next: NextFunction) => void;
/**
 * Convenience middleware functions for specific account types
 */
export declare const requireBroker: (req: AuthRequest, res: Response, next: NextFunction) => void;
export declare const requireCarrier: (req: AuthRequest, res: Response, next: NextFunction) => void;
export declare const requireShipper: (req: AuthRequest, res: Response, next: NextFunction) => void;
export declare const requireBrokerOrCarrier: (req: AuthRequest, res: Response, next: NextFunction) => void;
export declare const requireShipperOrBroker: (req: AuthRequest, res: Response, next: NextFunction) => void;
//# sourceMappingURL=authorization.middleware.d.ts.map