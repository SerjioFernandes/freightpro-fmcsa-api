import { logger } from '../utils/logger.js';
import { config } from '../config/environment.js';
export function errorHandler(err, req, res, next) {
    logger.error('Unhandled error', {
        message: err?.message || 'Unknown error',
        stack: err?.stack,
        route: req.originalUrl,
        method: req.method,
        requestId: req.requestId,
        user: req.userContext || null
    });
    if (res.headersSent) {
        return next(err);
    }
    res.status(err.status || 500).json({
        error: 'Internal Server Error',
        message: config.NODE_ENV === 'development' ? (err.message || 'Unknown error') : 'An unexpected error occurred',
    });
}
export function asyncHandler(fn) {
    return (req, res, next) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
}
//# sourceMappingURL=error.middleware.js.map