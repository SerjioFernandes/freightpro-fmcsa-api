import { Request, Response, NextFunction } from 'express';
import { AuthRequest } from '../types/index.js';
export declare function errorHandler(err: any, req: AuthRequest, res: Response, next: NextFunction): void;
export declare function asyncHandler(fn: Function): (req: Request, res: Response, next: NextFunction) => void;
//# sourceMappingURL=error.middleware.d.ts.map