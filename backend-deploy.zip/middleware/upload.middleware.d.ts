import multer from 'multer';
export declare const uploadDocument: multer.Multer;
export declare const uploadAvatar: multer.Multer;
export declare const getFileUrl: (filename: string, type: "document" | "avatar") => string;
export declare const deleteFile: (filepath: string) => void;
//# sourceMappingURL=upload.middleware.d.ts.map