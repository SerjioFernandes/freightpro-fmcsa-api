import { Response, NextFunction } from 'express';
import { AuthRequest } from '../types/index.js';
export declare function authenticateToken(req: AuthRequest, res: Response, next: NextFunction): void;
export declare function authenticateAdmin(req: AuthRequest, res: Response, next: NextFunction): void;
//# sourceMappingURL=auth.middleware.d.ts.map