declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=support.routes.d.ts.map