declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=load.routes.d.ts.map