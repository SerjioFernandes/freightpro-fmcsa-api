declare function seedLoads(): Promise<void>;
export { seedLoads };
//# sourceMappingURL=seedLoads.d.ts.map