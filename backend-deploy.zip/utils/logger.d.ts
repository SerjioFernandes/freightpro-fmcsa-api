import winston from 'winston';
export declare const logger: winston.Logger;
export declare function log(level: string, message: string, meta?: Record<string, any>): void;
//# sourceMappingURL=logger.d.ts.map