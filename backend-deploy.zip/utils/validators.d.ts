import { Country } from '../types/index.js';
export declare function validateEIN(ein: string): boolean;
export declare function validateMCNumber(mc: string): boolean;
export declare function validateUSDOTNumber(usdot: string): boolean;
export declare function validatePhone(phone: string): boolean;
export declare function validateEmail(email: string): boolean;
export declare function validatePostalCode(zip: string, country?: Country): boolean;
export declare function validateState(state: string, country?: Country): boolean;
export declare function normalizeMCNumber(mc: string): string;
export declare function normalizePhone(phone: string): string;
export declare function normalizeEIN(ein: string): {
    canon: string;
    display: string;
};
//# sourceMappingURL=validators.d.ts.map