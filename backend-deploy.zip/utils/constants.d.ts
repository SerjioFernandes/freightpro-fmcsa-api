export declare const VALIDATION_PATTERNS: {
    EIN: RegExp;
    MC_NUMBER: RegExp;
    USDOT_NUMBER: RegExp;
    PHONE: RegExp;
    EMAIL: RegExp;
    US_ZIP: RegExp;
    CA_POSTAL: RegExp;
};
export declare const US_STATES: string[];
export declare const CA_PROVINCES: string[];
export declare const RATE_LIMIT: {
    WINDOW_MS: number;
    MAX_REQUESTS: number;
};
export declare const PAGINATION: {
    DEFAULT_PAGE: number;
    DEFAULT_LIMIT: number;
    MAX_LIMIT: number;
};
//# sourceMappingURL=constants.d.ts.map