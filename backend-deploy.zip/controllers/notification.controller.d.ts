import { Response } from 'express';
import { AuthRequest } from '../types/index.js';
export declare class NotificationController {
    /**
     * GET /api/notifications
     * Get all notifications for the authenticated user
     */
    getNotifications(req: AuthRequest, res: Response): Promise<void>;
    /**
     * PUT /api/notifications/:id/read
     * Mark a specific notification as read
     */
    markAsRead(req: AuthRequest, res: Response): Promise<void>;
    /**
     * PUT /api/notifications/read-all
     * Mark all notifications as read
     */
    markAllAsRead(req: AuthRequest, res: Response): Promise<void>;
    /**
     * PUT /api/notifications/:id/important
     * Toggle important status
     */
    toggleImportant(req: AuthRequest, res: Response): Promise<void>;
    /**
     * DELETE /api/notifications/:id
     * Delete a specific notification
     */
    deleteNotification(req: AuthRequest, res: Response): Promise<void>;
    /**
     * DELETE /api/notifications
     * Delete all notifications (optional filters)
     */
    deleteAllNotifications(req: AuthRequest, res: Response): Promise<void>;
    /**
     * GET /api/notifications/preferences
     * Get notification preferences for the user
     */
    getPreferences(req: AuthRequest, res: Response): Promise<void>;
}
export declare const notificationController: NotificationController;
//# sourceMappingURL=notification.controller.d.ts.map