import { Response } from 'express';
import { AuthRequest } from '../types/index.js';
export declare class LocationController {
    /**
     * Geocode address to coordinates
     * GET /api/locations/geocode?city=Chicago&state=IL&zip=60601&country=US
     */
    geocode(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Reverse geocode coordinates to address
     * GET /api/locations/reverse?lat=41.8781&lng=-87.6298
     */
    reverseGeocode(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Calculate distance between two points
     * POST /api/locations/distance
     * Body: { point1: { lat, lng }, point2: { lat, lng } }
     */
    calculateDistance(req: AuthRequest, res: Response): Promise<void>;
}
export declare const locationController: LocationController;
//# sourceMappingURL=location.controller.d.ts.map