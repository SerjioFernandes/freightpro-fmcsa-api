import { seedLoads } from '../scripts/seedLoads.js';
import { logger } from '../utils/logger.js';
export class AdminController {
    /**
     * Seed loads for testing/demo purposes
     * GET /api/admin/seed-loads
     */
    async seedLoads(_req, res) {
        try {
            logger.info('Admin seed loads triggered');
            // Run seed in background
            seedLoads().catch((error) => {
                logger.error('Seed loads failed', { error });
            });
            res.json({
                success: true,
                message: 'Load seeding started in background. This may take a few minutes.'
            });
        }
        catch (error) {
            logger.error('Failed to start seed loads', { error: error.message });
            res.status(500).json({
                success: false,
                error: 'Failed to start seed loads'
            });
        }
    }
}
export const adminController = new AdminController();
//# sourceMappingURL=admin.controller.js.map