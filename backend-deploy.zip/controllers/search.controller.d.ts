import { Response } from 'express';
import { AuthRequest } from '../types/index.js';
export declare class SearchController {
    /**
     * POST /api/search/loads
     * Advanced search for loads
     */
    searchLoads(req: AuthRequest, res: Response): Promise<void>;
    /**
     * GET /api/search/autocomplete
     * Autocomplete for city/state searches
     */
    autocomplete(req: AuthRequest, res: Response): Promise<void>;
    /**
     * GET /api/search/popular
     * Get popular search terms
     */
    getPopularSearches(req: AuthRequest, res: Response): Promise<void>;
    /**
     * GET /api/search/recent
     * Get recent searches for the user
     */
    getRecentSearches(req: AuthRequest, res: Response): Promise<void>;
    /**
     * GET /api/search/suggestions
     * Get search suggestions based on query
     */
    getSuggestions(req: AuthRequest, res: Response): Promise<void>;
}
export declare const searchController: SearchController;
//# sourceMappingURL=search.controller.d.ts.map