import { Response } from 'express';
import { AuthRequest } from '../types/index.js';
export declare const getSettings: (req: AuthRequest, res: Response) => Promise<void>;
export declare const updateProfile: (req: AuthRequest, res: Response) => Promise<void>;
export declare const validateProfile: import("express-validator").ValidationChain[];
export declare const changePassword: (req: AuthRequest, res: Response) => Promise<void>;
export declare const updateNotificationSettings: (req: AuthRequest, res: Response) => Promise<void>;
export declare const uploadAvatar: (req: AuthRequest, res: Response) => Promise<void>;
export declare const validatePassword: import("express-validator").ValidationChain[];
//# sourceMappingURL=settings.controller.d.ts.map