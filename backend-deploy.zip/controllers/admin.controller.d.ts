import { Response } from 'express';
import { AuthRequest } from '../types/index.js';
export declare class AdminController {
    /**
     * Seed loads for testing/demo purposes
     * GET /api/admin/seed-loads
     */
    seedLoads(_req: AuthRequest, res: Response): Promise<void>;
}
export declare const adminController: AdminController;
//# sourceMappingURL=admin.controller.d.ts.map