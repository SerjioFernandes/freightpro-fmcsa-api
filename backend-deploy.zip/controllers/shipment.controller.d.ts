import { Response } from 'express';
import { AuthRequest } from '../types/index.js';
export declare class ShipmentController {
    getShipments(req: AuthRequest, res: Response): Promise<void>;
    createShipment(req: AuthRequest, res: Response): Promise<void>;
    getShipment(req: AuthRequest, res: Response): Promise<void>;
    updateShipment(req: AuthRequest, res: Response): Promise<void>;
    deleteShipment(req: AuthRequest, res: Response): Promise<void>;
    getShipmentRequests(req: AuthRequest, res: Response): Promise<void>;
    createShipmentRequest(req: AuthRequest, res: Response): Promise<void>;
    updateShipmentRequestStatus(req: AuthRequest, res: Response): Promise<void>;
}
export declare const shipmentController: ShipmentController;
//# sourceMappingURL=shipment.controller.d.ts.map