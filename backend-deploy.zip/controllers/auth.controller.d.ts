import { Response } from 'express';
import { AuthRequest } from '../types/index.js';
export declare class AuthController {
    register(req: AuthRequest, res: Response): Promise<void>;
    login(req: AuthRequest, res: Response): Promise<void>;
    verifyEmail(req: AuthRequest, res: Response): Promise<void>;
    resendCode(req: AuthRequest, res: Response): Promise<void>;
    getCurrentUser(req: AuthRequest, res: Response): Promise<void>;
}
export declare const authController: AuthController;
//# sourceMappingURL=auth.controller.d.ts.map