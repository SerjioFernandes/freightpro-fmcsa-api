import { Response } from 'express';
import { AuthRequest } from '../types/index.js';
export declare class LoadController {
    getLoads(req: AuthRequest, res: Response): Promise<void>;
    postLoad(req: AuthRequest, res: Response): Promise<void>;
    bookLoad(req: AuthRequest, res: Response): Promise<void>;
}
export declare const loadController: LoadController;
//# sourceMappingURL=load.controller.d.ts.map