import { Response } from 'express';
import { AuthRequest } from '../types/index.js';
export declare class SessionController {
    /**
     * GET /api/sessions
     * Get all active sessions for the authenticated user
     */
    getSessions(req: AuthRequest, res: Response): Promise<void>;
    /**
     * DELETE /api/sessions/:token
     * Delete a specific session (logout from one device)
     */
    deleteSession(req: AuthRequest, res: Response): Promise<void>;
    /**
     * DELETE /api/sessions
     * Delete all sessions (logout from all devices)
     */
    deleteAllSessions(req: AuthRequest, res: Response): Promise<void>;
    /**
     * POST /api/sessions/refresh
     * Refresh session activity
     */
    refreshSession(req: AuthRequest, res: Response): Promise<void>;
    /**
     * GET /api/sessions/security
     * Get security information for active sessions
     */
    getSecurityInfo(req: AuthRequest, res: Response): Promise<void>;
}
export declare const sessionController: SessionController;
//# sourceMappingURL=session.controller.d.ts.map