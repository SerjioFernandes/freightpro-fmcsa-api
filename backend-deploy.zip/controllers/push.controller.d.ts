import { Request, Response } from 'express';
export declare const pushController: {
    /**
     * Get VAPID public key
     */
    getPublicKey(_req: Request, res: Response): Promise<void>;
    /**
     * Subscribe to push notifications
     */
    subscribe(req: Request, res: Response): Promise<void>;
    /**
     * Unsubscribe from push notifications
     */
    unsubscribe(req: Request, res: Response): Promise<void>;
    /**
     * Send test notification (for testing purposes)
     */
    sendTestNotification(req: Request, res: Response): Promise<void>;
};
//# sourceMappingURL=push.controller.d.ts.map