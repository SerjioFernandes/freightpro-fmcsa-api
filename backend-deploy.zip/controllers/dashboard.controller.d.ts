import { Response } from 'express';
import { AuthRequest } from '../types/index.js';
export declare class DashboardController {
    getCarrierStats(req: AuthRequest, res: Response): Promise<void>;
    getBrokerStats(req: AuthRequest, res: Response): Promise<void>;
    getShipperStats(req: AuthRequest, res: Response): Promise<void>;
    getStats(req: AuthRequest, res: Response): Promise<void>;
}
export declare const dashboardController: DashboardController;
//# sourceMappingURL=dashboard.controller.d.ts.map