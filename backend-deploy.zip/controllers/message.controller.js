import { Message } from '../models/Message.model.js';
import { User } from '../models/User.model.js';
import mongoose from 'mongoose';
import { websocketService } from '../services/websocket.service.js';
export const getConversations = async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId) {
            res.status(401).json({ error: 'Unauthorized' });
            return;
        }
        // Get all unique users you've had conversations with
        const conversations = await Message.aggregate([
            {
                $match: {
                    $or: [
                        { sender: new mongoose.Types.ObjectId(userId) },
                        { receiver: new mongoose.Types.ObjectId(userId) }
                    ]
                }
            },
            {
                $sort: { createdAt: -1 }
            },
            {
                $group: {
                    _id: {
                        $cond: [
                            { $eq: ['$sender', new mongoose.Types.ObjectId(userId)] },
                            '$receiver',
                            '$sender'
                        ]
                    },
                    lastMessage: { $first: '$$ROOT' },
                    unreadCount: {
                        $sum: {
                            $cond: [
                                {
                                    $and: [
                                        { $eq: ['$receiver', new mongoose.Types.ObjectId(userId)] },
                                        { $eq: ['$isRead', false] }
                                    ]
                                },
                                1,
                                0
                            ]
                        }
                    }
                }
            },
            {
                $lookup: {
                    from: 'users',
                    localField: '_id',
                    foreignField: '_id',
                    as: 'user'
                }
            },
            {
                $unwind: {
                    path: '$user',
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $project: {
                    userId: '$_id',
                    company: '$user.company',
                    email: '$user.email',
                    accountType: '$user.accountType',
                    lastMessage: {
                        subject: '$lastMessage.subject',
                        message: '$lastMessage.message',
                        createdAt: '$lastMessage.createdAt'
                    },
                    unreadCount: 1
                }
            },
            {
                $sort: { 'lastMessage.createdAt': -1 }
            }
        ]);
        res.json({
            success: true,
            data: conversations
        });
    }
    catch (error) {
        console.error('Get conversations error:', error);
        res.status(500).json({ error: 'Failed to fetch conversations' });
    }
};
export const getConversation = async (req, res) => {
    try {
        const userId = req.user?.userId;
        const otherUserId = req.params.userId;
        if (!userId || !otherUserId) {
            res.status(400).json({ error: 'Invalid request' });
            return;
        }
        // Get all messages between current user and other user
        const messages = await Message.find({
            $or: [
                { sender: userId, receiver: otherUserId },
                { sender: otherUserId, receiver: userId }
            ]
        })
            .populate('sender', 'company email accountType')
            .populate('receiver', 'company email accountType')
            .sort({ createdAt: 1 });
        // Mark messages as read
        await Message.updateMany({
            sender: otherUserId,
            receiver: userId,
            isRead: false
        }, {
            $set: { isRead: true }
        });
        res.json({
            success: true,
            data: messages
        });
    }
    catch (error) {
        console.error('Get conversation error:', error);
        res.status(500).json({ error: 'Failed to fetch conversation' });
    }
};
export const sendMessage = async (req, res) => {
    try {
        const userId = req.user?.userId;
        const { receiverId, subject, message } = req.body;
        if (!userId || !receiverId || !subject || !message) {
            res.status(400).json({ error: 'Missing required fields' });
            return;
        }
        // Verify receiver exists
        const receiver = await User.findById(receiverId);
        if (!receiver) {
            res.status(404).json({ error: 'Receiver not found' });
            return;
        }
        // Create message
        const newMessage = await Message.create({
            sender: userId,
            receiver: receiverId,
            subject,
            message,
            isRead: false
        });
        // Populate before sending
        await newMessage.populate('sender', 'company email accountType');
        await newMessage.populate('receiver', 'company email accountType');
        // Broadcast new message via WebSocket
        websocketService.emitToUser(receiverId, 'new_message', newMessage);
        res.status(201).json({
            success: true,
            message: 'Message sent successfully',
            data: newMessage
        });
    }
    catch (error) {
        console.error('Send message error:', error);
        res.status(500).json({ error: 'Failed to send message' });
    }
};
export const getUnreadCount = async (req, res) => {
    try {
        const userId = req.user?.userId;
        const unreadCount = await Message.countDocuments({
            receiver: userId,
            isRead: false
        });
        res.json({
            success: true,
            data: { count: unreadCount }
        });
    }
    catch (error) {
        console.error('Get unread count error:', error);
        res.status(500).json({ error: 'Failed to fetch unread count' });
    }
};
export const editMessage = async (req, res) => {
    try {
        const userId = req.user?.userId;
        const { message } = req.body;
        const msg = await Message.findById(req.params.id);
        if (!msg) {
            res.status(404).json({ error: 'Message not found' });
            return;
        }
        // Check if user is the sender
        if (msg.sender.toString() !== userId) {
            res.status(403).json({ error: 'You can only edit your own messages' });
            return;
        }
        // Only allow editing within 5 minutes
        const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
        if (msg.createdAt < fiveMinutesAgo) {
            res.status(400).json({ error: 'Messages can only be edited within 5 minutes' });
            return;
        }
        // Update message
        msg.message = message;
        msg.isEdited = true;
        msg.editedAt = new Date();
        await msg.save();
        // Broadcast message update via WebSocket
        websocketService.emitToUser(msg.receiver.toString(), 'message_updated', msg);
        res.json({
            success: true,
            message: 'Message updated successfully',
            data: msg
        });
    }
    catch (error) {
        console.error('Edit message error:', error);
        res.status(500).json({ error: 'Failed to edit message' });
    }
};
export const deleteMessage = async (req, res) => {
    try {
        const userId = req.user?.userId;
        const msg = await Message.findById(req.params.id);
        if (!msg) {
            res.status(404).json({ error: 'Message not found' });
            return;
        }
        // Check if user is the sender
        if (msg.sender.toString() !== userId) {
            res.status(403).json({ error: 'You can only delete your own messages' });
            return;
        }
        await msg.deleteOne();
        // Broadcast message deletion via WebSocket
        websocketService.emitToUser(msg.receiver.toString(), 'message_deleted', {
            messageId: msg._id,
            conversationId: msg.sender === msg.receiver ? msg.sender.toString() : undefined
        });
        res.json({
            success: true,
            message: 'Message deleted successfully'
        });
    }
    catch (error) {
        console.error('Delete message error:', error);
        res.status(500).json({ error: 'Failed to delete message' });
    }
};
//# sourceMappingURL=message.controller.js.map