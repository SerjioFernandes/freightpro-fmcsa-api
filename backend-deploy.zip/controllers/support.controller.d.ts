import { Response } from 'express';
import { AuthRequest } from '../types/index.js';
export declare const chat: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=support.controller.d.ts.map