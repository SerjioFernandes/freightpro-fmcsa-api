import { Response } from 'express';
import { AuthRequest } from '../types/index.js';
export declare class SavedSearchController {
    /**
     * Get all saved searches for current user
     * GET /api/searches
     */
    getSearches(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Create a new saved search
     * POST /api/searches
     */
    createSearch(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Update a saved search
     * PUT /api/searches/:id
     */
    updateSearch(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Toggle alert for a saved search
     * PUT /api/searches/:id/alert
     */
    toggleAlert(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Delete a saved search
     * DELETE /api/searches/:id
     */
    deleteSearch(req: AuthRequest, res: Response): Promise<void>;
}
export declare const savedSearchController: SavedSearchController;
//# sourceMappingURL=savedSearch.controller.d.ts.map