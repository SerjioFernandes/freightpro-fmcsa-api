import { EnvironmentConfig } from '../types/index.js';
export declare const config: EnvironmentConfig;
export declare function validateEnvironment(): void;
//# sourceMappingURL=environment.d.ts.map