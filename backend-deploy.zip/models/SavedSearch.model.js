import mongoose, { Schema } from 'mongoose';
const savedSearchSchema = new Schema({
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    name: { type: String, required: true },
    filters: {
        equipment: [{ type: String }],
        priceMin: { type: Number },
        priceMax: { type: Number },
        originState: { type: String },
        destinationState: { type: String },
        dateRange: {
            from: { type: Date },
            to: { type: Date }
        },
        radius: { type: Number }
    },
    alertEnabled: { type: Boolean, default: true },
    frequency: { type: String, enum: ['instant', 'daily', 'weekly'], default: 'instant' },
    lastAlertSent: { type: Date },
    createdAt: { type: Date, default: Date.now }
});
// Indexes
savedSearchSchema.index({ userId: 1, createdAt: -1 });
savedSearchSchema.index({ alertEnabled: 1, frequency: 1, lastAlertSent: 1 });
export const SavedSearch = mongoose.model('SavedSearch', savedSearchSchema);
//# sourceMappingURL=SavedSearch.model.js.map