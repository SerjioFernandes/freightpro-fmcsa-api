import mongoose, { Model } from 'mongoose';
export interface ISavedSearch {
    userId: mongoose.Types.ObjectId;
    name: string;
    filters: {
        equipment: string[];
        priceMin?: number;
        priceMax?: number;
        originState?: string;
        destinationState?: string;
        dateRange?: {
            from: Date;
            to: Date;
        };
        radius?: number;
    };
    alertEnabled: boolean;
    frequency: 'instant' | 'daily' | 'weekly';
    lastAlertSent?: Date;
    createdAt: Date;
}
export declare const SavedSearch: Model<ISavedSearch>;
//# sourceMappingURL=SavedSearch.model.d.ts.map