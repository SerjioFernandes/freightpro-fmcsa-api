import { Model } from 'mongoose';
import { IMessage } from '../types/index.js';
export declare const Message: Model<IMessage>;
//# sourceMappingURL=Message.model.d.ts.map