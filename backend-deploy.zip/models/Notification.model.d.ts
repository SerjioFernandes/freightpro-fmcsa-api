import mongoose, { Model, Types } from 'mongoose';
export interface INotification extends mongoose.Document {
    userId: Types.ObjectId;
    type: 'info' | 'warning' | 'success' | 'error' | 'load_update' | 'message' | 'shipment' | 'system';
    title: string;
    message: string;
    data?: Record<string, any>;
    isRead: boolean;
    isImportant: boolean;
    actionUrl?: string;
    expiresAt?: Date;
    createdAt: Date;
    readAt?: Date;
}
export declare const Notification: Model<INotification>;
//# sourceMappingURL=Notification.model.d.ts.map