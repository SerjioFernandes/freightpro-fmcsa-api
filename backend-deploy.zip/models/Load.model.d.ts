import { Model } from 'mongoose';
import { ILoad } from '../types/index.js';
export declare const Load: Model<ILoad>;
//# sourceMappingURL=Load.model.d.ts.map