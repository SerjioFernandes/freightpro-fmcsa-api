import { Model } from 'mongoose';
import { IShipment, IShipmentRequest } from '../types/index.js';
export declare const Shipment: Model<IShipment>;
export declare const ShipmentRequest: Model<IShipmentRequest>;
//# sourceMappingURL=Shipment.model.d.ts.map