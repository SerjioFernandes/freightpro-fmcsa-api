import { Model } from 'mongoose';
import { IUser } from '../types/index.js';
export declare const User: Model<IUser>;
//# sourceMappingURL=User.model.d.ts.map