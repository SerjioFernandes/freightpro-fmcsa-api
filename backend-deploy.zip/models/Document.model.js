import mongoose, { Schema } from 'mongoose';
const documentSchema = new Schema({
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    loadId: { type: Schema.Types.ObjectId, ref: 'Load' },
    shipmentId: { type: Schema.Types.ObjectId, ref: 'Shipment' },
    type: {
        type: String,
        enum: ['BOL', 'POD', 'INSURANCE', 'LICENSE', 'CARRIER_AUTHORITY', 'W9', 'OTHER'],
        required: true
    },
    filename: { type: String, required: true },
    originalName: { type: String, required: true },
    mimeType: { type: String, required: true },
    size: { type: Number, required: true },
    url: { type: String, required: true },
    uploadedAt: { type: Date, default: Date.now },
    expiresAt: { type: Date },
    isVerified: { type: Boolean, default: false },
    verifiedBy: { type: Schema.Types.ObjectId, ref: 'User' },
    verifiedAt: { type: Date }
});
// Indexes for performance
documentSchema.index({ userId: 1, uploadedAt: -1 });
documentSchema.index({ loadId: 1 });
documentSchema.index({ shipmentId: 1 });
documentSchema.index({ type: 1 });
export const Document = mongoose.model('Document', documentSchema);
//# sourceMappingURL=Document.model.js.map