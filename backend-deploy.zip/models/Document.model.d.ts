import { Model } from 'mongoose';
import { IDocument } from '../types/index.js';
export declare const Document: Model<IDocument>;
//# sourceMappingURL=Document.model.d.ts.map