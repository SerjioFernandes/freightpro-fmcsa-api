import mongoose, { Document } from 'mongoose';
export interface IPushSubscription extends Document {
    userId: mongoose.Types.ObjectId;
    endpoint: string;
    keys: {
        p256dh: string;
        auth: string;
    };
    createdAt: Date;
    updatedAt: Date;
}
export declare const PushSubscription: mongoose.Model<IPushSubscription, {}, {}, {}, mongoose.Document<unknown, {}, IPushSubscription, {}, {}> & IPushSubscription & Required<{
    _id: unknown;
}> & {
    __v: number;
}, any>;
//# sourceMappingURL=PushSubscription.model.d.ts.map