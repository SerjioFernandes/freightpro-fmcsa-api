export interface SearchFilters {
    query?: string;
    originState?: string;
    destinationState?: string;
    equipment?: string[];
    minRate?: number;
    maxRate?: number;
    minWeight?: number;
    maxWeight?: number;
    status?: string[];
    pickupDateFrom?: Date;
    pickupDateTo?: Date;
    postedBy?: string;
    bookedBy?: string;
}
export interface SearchSuggestion {
    type: 'origin' | 'destination' | 'equipment' | 'city';
    value: string;
    count: number;
}
declare class SearchService {
    /**
     * Advanced search with multiple filters and relevance scoring
     */
    searchLoads(filters: SearchFilters, page?: number, limit?: number): Promise<{
        loads: any[];
        total: number;
        suggestions?: SearchSuggestion[];
    }>;
    /**
     * Generate search suggestions based on query
     */
    generateSuggestions(_query: string, _limit?: number): Promise<SearchSuggestion[]>;
    /**
     * Autocomplete for city/state searches
     */
    autocompleteCityState(query: string, type?: 'origin' | 'destination', limit?: number): Promise<string[]>;
    /**
     * Get recently searched terms (requires a separate model if tracking searches)
     */
    getRecentSearches(_userId: string, _limit?: number): Promise<string[]>;
    /**
     * Get popular search terms
     */
    getPopularSearches(limit?: number): Promise<Array<{
        term: string;
        count: number;
    }>>;
}
export declare const searchService: SearchService;
export {};
//# sourceMappingURL=search.service.d.ts.map