import webpush from 'web-push';
import { config } from '../config/environment.js';
import { logger } from '../utils/logger.js';
// Generate VAPID keys (run once and store in environment variables)
// const vapidKeys = webpush.generateVAPIDKeys();
// console.log('VAPID Public Key:', vapidKeys.publicKey);
// console.log('VAPID Private Key:', vapidKeys.privateKey);
const VAPID_PUBLIC_KEY = config.VAPID_PUBLIC_KEY;
const VAPID_PRIVATE_KEY = config.VAPID_PRIVATE_KEY;
const VAPID_SUBJECT = config.VAPID_SUBJECT || 'mailto:admin@cargolume.com';
// Only enable if both keys are provided and not empty strings
const VAPID_ENABLED = !!(VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY &&
    VAPID_PUBLIC_KEY.trim() !== '' && VAPID_PRIVATE_KEY.trim() !== '');
// Configure web-push only if VAPID keys are provided
if (VAPID_ENABLED) {
    try {
        webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
        logger.info('Push notification service initialized with VAPID keys');
    }
    catch (error) {
        logger.error('Failed to configure VAPID keys', { error: error.message });
        logger.warn('Push notifications will be disabled');
    }
}
else {
    logger.warn('VAPID keys not configured - push notifications disabled');
}
class PushService {
    /**
     * Send push notification to a specific subscription
     */
    async sendNotification(subscription, notification) {
        if (!VAPID_ENABLED) {
            logger.warn('Push notifications disabled - VAPID keys not configured');
            return;
        }
        try {
            const payload = JSON.stringify({
                title: notification.title,
                body: notification.body,
                icon: notification.icon || '/assets/icons/icon-192.png',
                badge: notification.badge || '/assets/icons/badge-72.png',
                data: notification.data || {},
                actions: notification.actions || []
            });
            await webpush.sendNotification(subscription, payload);
            logger.info('Push notification sent successfully', {
                endpoint: subscription.endpoint.substring(0, 50) + '...'
            });
        }
        catch (error) {
            logger.error('Failed to send push notification', { error: error.message });
            // Handle different error codes
            if (error.statusCode === 410) {
                logger.warn('Push subscription expired', { endpoint: subscription.endpoint });
                // TODO: Remove expired subscription from database
            }
            throw error;
        }
    }
    /**
     * Send notification to multiple subscriptions
     */
    async sendNotificationToMany(subscriptions, notification) {
        let success = 0;
        let failed = 0;
        const promises = subscriptions.map(async (subscription) => {
            try {
                await this.sendNotification(subscription, notification);
                success++;
            }
            catch (error) {
                failed++;
            }
        });
        await Promise.all(promises);
        logger.info('Batch push notification complete', { success, failed });
        return { success, failed };
    }
    /**
     * Get VAPID public key for frontend
     */
    getPublicKey() {
        return VAPID_PUBLIC_KEY || '';
    }
    /**
     * Validate subscription object
     */
    isValidSubscription(subscription) {
        return (subscription &&
            typeof subscription.endpoint === 'string' &&
            subscription.keys &&
            typeof subscription.keys.p256dh === 'string' &&
            typeof subscription.keys.auth === 'string');
    }
}
export const pushService = new PushService();
//# sourceMappingURL=push.service.js.map