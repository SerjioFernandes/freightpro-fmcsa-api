declare class EmailService {
    private transporter;
    constructor();
    private initialize;
    sendVerificationEmail(email: string, code: string): Promise<boolean>;
    sendResendCodeEmail(email: string, code: string): Promise<boolean>;
    testConnection(): Promise<boolean>;
    /**
     * Generic email send method
     */
    sendEmail(data: {
        to: string;
        subject: string;
        html: string;
    }): Promise<boolean>;
    isConfigured(): boolean;
}
export declare const emailService: EmailService;
export {};
//# sourceMappingURL=email.service.d.ts.map