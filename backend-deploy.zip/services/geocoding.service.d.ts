interface GeoPoint {
    latitude: number;
    longitude: number;
}
interface Address {
    city: string;
    state: string;
    zip: string;
    country?: string;
}
declare class GeocodingService {
    private geocoder;
    constructor();
    /**
     * Geocode address to coordinates
     */
    geocodeAddress(address: Address): Promise<GeoPoint | null>;
    /**
     * Reverse geocode coordinates to address
     */
    reverseGeocode(latitude: number, longitude: number): Promise<Address | null>;
    /**
     * Calculate distance between two points (Haversine formula)
     * Returns distance in miles
     */
    calculateDistance(point1: GeoPoint, point2: GeoPoint): number;
    /**
     * Convert degrees to radians
     */
    private toRadians;
    /**
     * Find nearby loads within radius
     */
    findNearbyLoads(location: GeoPoint, loads: Array<{
        origin: Address;
        destination: Address;
        [key: string]: any;
    }>, radiusMiles: number): Promise<Array<{
        load: any;
        distance: number;
    }>>;
}
export declare const geocodingService: GeocodingService;
export {};
//# sourceMappingURL=geocoding.service.d.ts.map