import { INotification } from '../models/Notification.model.js';
export interface CreateNotificationData {
    userId: string;
    type: INotification['type'];
    title: string;
    message: string;
    data?: Record<string, any>;
    isImportant?: boolean;
    actionUrl?: string;
    expiresIn?: number;
}
declare class NotificationService {
    /**
     * Create a new notification
     */
    createNotification(data: CreateNotificationData): Promise<INotification>;
    /**
     * Get all notifications for a user (paginated)
     */
    getUserNotifications(userId: string, page?: number, limit?: number, filters?: {
        isRead?: boolean;
        type?: string;
        isImportant?: boolean;
    }): Promise<{
        notifications: INotification[];
        total: number;
        unreadCount: number;
    }>;
    /**
     * Mark notification as read
     */
    markAsRead(notificationId: string, userId: string): Promise<boolean>;
    /**
     * Mark all notifications as read for a user
     */
    markAllAsRead(userId: string): Promise<number>;
    /**
     * Toggle important status
     */
    toggleImportant(notificationId: string, userId: string): Promise<INotification | null>;
    /**
     * Delete a notification
     */
    deleteNotification(notificationId: string, userId: string): Promise<boolean>;
    /**
     * Delete all notifications for a user (optional: filter by type or read status)
     */
    deleteAllNotifications(userId: string, filters?: {
        isRead?: boolean;
        type?: string;
    }): Promise<number>;
    /**
     * Get notification preferences for a user (from User model)
     */
    getNotificationPreferences(_userId: string): Promise<any>;
}
export declare const notificationService: NotificationService;
export {};
//# sourceMappingURL=notification.service.d.ts.map