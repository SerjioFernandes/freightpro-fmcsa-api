import type { AccountType } from '../types/index.js';
export interface TimeSeriesData {
    date: string;
    value: number;
    count?: number;
}
export interface RevenueAnalytics {
    total: number;
    average: number;
    trend: 'up' | 'down' | 'stable';
    change: number;
}
export interface LoadAnalytics {
    total: number;
    active: number;
    completed: number;
    cancelled: number;
    trend: 'up' | 'down' | 'stable';
    change: number;
}
declare class AnalyticsService {
    /**
     * Get revenue time series for a carrier
     */
    getCarrierRevenueTimeSeries(carrierId: string, days?: number): Promise<TimeSeriesData[]>;
    /**
     * Get load count time series for a carrier
     */
    getCarrierLoadCountTimeSeries(carrierId: string, days?: number): Promise<TimeSeriesData[]>;
    /**
     * Get revenue analytics for a carrier
     */
    getCarrierRevenueAnalytics(carrierId: string, days?: number): Promise<RevenueAnalytics>;
    /**
     * Get load analytics for a carrier
     */
    getCarrierLoadAnalytics(carrierId: string, days?: number): Promise<LoadAnalytics>;
    /**
     * Get broker posted loads time series
     */
    getBrokerLoadsTimeSeries(brokerId: string, days?: number): Promise<TimeSeriesData[]>;
    /**
     * Get shipper shipments time series
     */
    getShipperShipmentsTimeSeries(shipperId: string, days?: number): Promise<TimeSeriesData[]>;
    /**
     * Get top equipment types by usage
     */
    getTopEquipmentTypes(userId: string, accountType: AccountType, limit?: number): Promise<Array<{
        type: string;
        count: number;
    }>>;
}
export declare const analyticsService: AnalyticsService;
export {};
//# sourceMappingURL=analytics.service.d.ts.map