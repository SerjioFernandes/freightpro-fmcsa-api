import { AccountType } from '../types/index.js';
interface RegisterData {
    email: string;
    password: string;
    company: string;
    phone: string;
    accountType: AccountType;
    usdotNumber?: string;
    mcNumber?: string;
    hasUSDOT?: boolean;
    companyLegalName?: string;
    dbaName?: string;
    ein?: string;
}
export declare class AuthService {
    register(data: RegisterData): Promise<{
        user: {
            id: import("mongoose").Types.ObjectId;
            email: string;
            company: string;
            accountType: AccountType;
            isEmailVerified: boolean;
        };
        emailSent: boolean;
        verificationCode: string;
    }>;
    login(email: string, password: string, userAgent: string, ip: string): Promise<{
        token: string;
        user: {
            id: import("mongoose").Types.ObjectId;
            email: string;
            company: string;
            phone: string;
            accountType: AccountType;
            usdotNumber: string | undefined;
            mcNumber: string | undefined;
            hasUSDOT: boolean;
            hasMC: boolean;
            isEmailVerified: true;
            role: import("../types/index.js").UserRole;
            subscriptionPlan: import("../types/index.js").SubscriptionPlan;
            premiumExpires: Date | undefined;
            profilePhoto: string;
            preferences: import("../types/index.js").IUserPreferences;
            notifications: import("../types/index.js").INotificationPreferences;
            createdAt: Date;
            lastLogin: Date;
        };
    }>;
    verifyEmail(email: string, code: string): Promise<{
        success: boolean;
        message: string;
    }>;
    resendVerificationCode(email: string): Promise<{
        success: boolean;
        message: string;
        verificationCode: string;
        emailSent: boolean;
    }>;
    ensureDefaultAdminUser(): Promise<void>;
}
export declare const authService: AuthService;
export {};
//# sourceMappingURL=auth.service.d.ts.map