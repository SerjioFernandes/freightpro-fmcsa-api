export interface PushSubscription {
    endpoint: string;
    keys: {
        p256dh: string;
        auth: string;
    };
}
export interface PushNotification {
    title: string;
    body: string;
    icon?: string;
    badge?: string;
    data?: any;
    actions?: Array<{
        action: string;
        title: string;
    }>;
}
declare class PushService {
    /**
     * Send push notification to a specific subscription
     */
    sendNotification(subscription: PushSubscription, notification: PushNotification): Promise<void>;
    /**
     * Send notification to multiple subscriptions
     */
    sendNotificationToMany(subscriptions: PushSubscription[], notification: PushNotification): Promise<{
        success: number;
        failed: number;
    }>;
    /**
     * Get VAPID public key for frontend
     */
    getPublicKey(): string;
    /**
     * Validate subscription object
     */
    isValidSubscription(subscription: any): subscription is PushSubscription;
}
export declare const pushService: PushService;
export {};
//# sourceMappingURL=push.service.d.ts.map