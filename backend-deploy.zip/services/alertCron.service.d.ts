declare class AlertCronService {
    private cronJob;
    /**
     * Start alert cron job
     */
    start(): void;
    /**
     * Stop alert cron job
     */
    stop(): void;
    /**
     * Process all saved searches and send alerts
     */
    private processAlerts;
    /**
     * Check if alert should be sent based on frequency and last sent time
     */
    private shouldSendAlert;
    /**
     * Find loads matching saved search criteria
     */
    private findMatchingLoads;
    /**
     * Send alert email to user
     */
    private sendAlert;
}
export declare const alertCronService: AlertCronService;
export {};
//# sourceMappingURL=alertCron.service.d.ts.map