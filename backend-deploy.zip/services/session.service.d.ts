export interface SessionData {
    token: string;
    device: string;
    ip: string;
    userAgent?: string;
}
declare class SessionService {
    /**
     * Create a new session for a user
     */
    createSession(userId: string, sessionData: SessionData): Promise<boolean>;
    /**
     * Get all active sessions for a user
     */
    getUserSessions(userId: string): Promise<any[]>;
    /**
     * Update session last activity
     */
    updateSessionActivity(userId: string, token: string): Promise<boolean>;
    /**
     * Delete a specific session (logout from one device)
     */
    deleteSession(userId: string, token: string): Promise<boolean>;
    /**
     * Delete all sessions for a user (logout from all devices)
     */
    deleteAllSessions(userId: string): Promise<boolean>;
    /**
     * Get session details for display
     */
    getSessionDisplayData(sessions: any[]): Array<{
        token: string;
        device: string;
        ip: string;
        userAgent?: string;
        lastActivity: Date;
        createdAt: Date;
        isCurrent?: boolean;
    }>;
    /**
     * Detect device type from user agent
     */
    detectDevice(userAgent: string): string;
    /**
     * Check if IP address is suspicious (rate limiting, etc.)
     */
    isSuspiciousActivity(_ip: string, sessions: any[]): boolean;
    /**
     * Clean up old inactive sessions (older than 30 days)
     */
    cleanupOldSessions(): Promise<number>;
}
export declare const sessionService: SessionService;
export {};
//# sourceMappingURL=session.service.d.ts.map