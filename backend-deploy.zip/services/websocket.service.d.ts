import { Server as HTTPServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
declare class WebSocketService {
    private io;
    private rooms;
    private userSockets;
    private socketUsers;
    /**
     * Initialize Socket.IO server
     */
    initialize(server: HTTPServer): void;
    /**
     * Authenticate socket connection
     */
    private authenticateSocket;
    /**
     * Handle new socket connection
     */
    private handleConnection;
    /**
     * Setup event handlers for socket
     */
    private setupEventHandlers;
    /**
     * Join a room
     */
    private joinRoom;
    /**
     * Leave a room
     */
    private leaveRoom;
    /**
     * Handle socket disconnection
     */
    private handleDisconnect;
    /**
     * Emit event to room
     */
    emitToRoom(roomName: string, event: string, data: any): void;
    /**
     * Emit event to user
     */
    emitToUser(userId: string, event: string, data: any): void;
    /**
     * Broadcast new load to relevant users
     */
    notifyNewLoad(load: any): void;
    /**
     * Broadcast load update
     */
    notifyLoadUpdate(loadId: string, updates: any): void;
    /**
     * Broadcast new message
     */
    notifyNewMessage(message: any): void;
    /**
     * Broadcast notification
     */
    notifyUser(userId: string, notification: any): void;
    /**
     * Get server instance
     */
    getServer(): SocketIOServer | null;
    /**
     * Get online users count
     */
    getOnlineUsersCount(): number;
    /**
     * Check if user is online
     */
    isUserOnline(userId: string): boolean;
}
export declare const websocketService: WebSocketService;
export {};
//# sourceMappingURL=websocket.service.d.ts.map